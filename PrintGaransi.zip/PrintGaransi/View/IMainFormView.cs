﻿using PrintPackingLabel.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrintPackingLabel.View
{
    public interface IMainFormView
    {
        void Show();
    }
}
