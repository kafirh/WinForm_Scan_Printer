﻿using PrintPackingLabel.Model;
using System;
using System.Drawing;
using System.Drawing.Printing;
using ZXing;
using ZXing.Windows.Compatibility;

namespace PrintPackingLabel.Presenter
{
    public class PrintPackingLabelLayout
    {
        public void Print(PrintPageEventArgs e, GaransiModel garansi)
        {
            PaperSize customPaperSize = new PaperSize("Custom", 276, 157);
            e.PageSettings.PaperSize = customPaperSize;
            e.PageSettings.Margins = new Margins(28, 28,0,0);

            int xPos = 28;
            int yPos = 10; 


            Font fontTitle = new Font("PudHinban", 10, FontStyle.Bold);
            Font fontBarcodeLabel = new Font("Arial", 6, FontStyle.Regular);

            // Menampilkan barcode untuk Model Number
            using (Bitmap barcodeModel = GenerateBarcode(garansi.ModelNumber))
            {
                e.Graphics.DrawImage(barcodeModel, new PointF(xPos, yPos));
                yPos += barcodeModel.Height - 5;

                var sizeLabel = e.Graphics.MeasureString("MODEL NO.", fontBarcodeLabel);
                e.Graphics.DrawString("MODEL NO.", fontBarcodeLabel, Brushes.Black, new PointF(xPos, yPos));
                e.Graphics.DrawString(garansi.ModelNumber, fontTitle, Brushes.Black, new PointF(xPos + sizeLabel.Width, yPos));
            }

            yPos += (int)e.Graphics.MeasureString(garansi.ModelNumber, fontTitle).Height;

            // Menampilkan barcode untuk Serial Number
            using (Bitmap barcodeSerial = GenerateBarcode(garansi.NoSeri))
            {
                e.Graphics.DrawImage(barcodeSerial, new PointF(xPos, yPos));
                yPos += barcodeSerial.Height - 5;

                var sizeLabel = e.Graphics.MeasureString("SERIAL NO.", fontBarcodeLabel);
                e.Graphics.DrawString("SERIAL NO.", fontBarcodeLabel, Brushes.Black, new PointF(xPos, yPos));
                e.Graphics.DrawString(garansi.NoSeri, fontTitle, Brushes.Black, new PointF(xPos + sizeLabel.Width, yPos));
            }
        }

        private Bitmap GenerateBarcode(string data)
        {
            var encodingOptions = new ZXing.Common.EncodingOptions
            {
                PureBarcode = true,
                Width = data.Length, // Perbesar otomatis sesuai panjang data
                Height = 50,
                Margin = 0
            };

            var writer = new BarcodeWriter
            {
                Format = BarcodeFormat.CODE_39,
                Options = encodingOptions
            };

            Bitmap barcode = writer.Write(data);

            // **Memperbesar bar tanpa merusak tata letak**
            float scaleFactor = 1.2f;
            int newWidth = (int)Math.Ceiling(barcode.Width * scaleFactor);
            int newHeight = barcode.Height;

            Bitmap resizedBarcode = new Bitmap(newWidth, newHeight);
            using (Graphics g = Graphics.FromImage(resizedBarcode))
            {
                g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.NearestNeighbor;
                g.PixelOffsetMode = System.Drawing.Drawing2D.PixelOffsetMode.None; // Mencegah pergeseran
                g.DrawImage(barcode, new Rectangle(0, 0, newWidth, newHeight));
            }

            return resizedBarcode;
        }
    }
}
